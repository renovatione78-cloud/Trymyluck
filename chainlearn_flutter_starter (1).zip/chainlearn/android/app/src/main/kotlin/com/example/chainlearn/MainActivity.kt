package com.example.chainlearn

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
