# Architecture & UI blueprint

## Screens

- **Home:** learning path, featured simulator, progress/concept cards.
- **Modules:** network state, mempool, and fee priority lessons.
- **Simulations:** local chain height, pending queue, low/standard/high-fee sample controls, block capacity and included block.
- **Profile:** beginner status, progress, and a privacy explanation.

## State flow

`SimulationScreen → simulationProvider → SimulationController → SimulationEngine → ChainState`

`SimulationController` is the only mutable boundary. The engine takes an immutable `ChainState` plus an action and returns a new state. `mineNextBlock` sorts pending transactions by fictional priority score, fills a fixed capacity in order when each transaction fits, advances height, creates a block record, and preserves transactions that do not fit. Reset restores the initial state. This is intentionally deterministic and uses made-up learning units.

## Visual rules

- Base: `#0F172A`; secondary card tint: translucent charcoal; primary text: `#F4F7FB`.
- Neon blue `#00F2FE` identifies active state and primary actions; electric violet `#4FACFE` marks secondary learning cues.
- Cards use a 22 px radius, a 1 px translucent border, backdrop blur, and a restrained blue glow on focused/active cards.
- Inter is loaded through Google Fonts. Text styles use Material's responsive theme scale; small labels stay at 10–12 px, body copy at 12–14 px, headings at 19–24 px.
- Bottom navigation has four destinations: Home, Modules, Simulations, Profile. `AnimatedSwitcher`, `InkWell`, and animated progress indicators provide lightweight transitions and tap feedback. Replace these with authored Lottie assets later if a branded animation set is available.
- Respect Android text scaling and safe areas. Keep actions at least 44 px high and maintain contrast; do not use color as the only status cue.

## Key directories

```text
lib/
  main.dart                         ProviderScope entry
  app/chainlearn_app.dart           Material app and theme binding
  core/theme/app_theme.dart         colors, type, navigation theme
  core/widgets/                    reusable glass cards and labels
  features/home/presentation/      dashboard
  features/modules/presentation/   lesson catalog
  features/simulations/domain/     immutable entities and engine
  features/simulations/data/       local preferences adapter
  features/simulations/presentation/ controller, shell, simulator, profile
android/app/src/main/              Android host manifest and MainActivity
```

For production packaging, generate the complete platform scaffold with `flutter create --platforms=android .`; this adds Gradle wrapper/configuration and launcher resources for the chosen application ID.
