import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_card.dart';

class ModulesScreen extends StatelessWidget {
  const ModulesScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    Text('Modules', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
    const SizedBox(height: 6), const Text('Short lessons that build from the basics.', style: TextStyle(color: AppColors.muted)), const SizedBox(height: 20),
    _lesson('01', 'Blockchain state', 'A chain is a shared, ordered record. Each accepted block advances the height and updates the state.', Icons.account_tree_outlined, '5 min'),
    _lesson('02', 'Pending transactions', 'Transactions wait in a mempool before a block includes them. A local node can have a different pending pool from another node.', Icons.pending_actions_outlined, '4 min'),
    _lesson('03', 'Low fee mechanics', 'When block space is scarce, a lower priority score may wait longer in this simplified example. Real networks use chain-specific rules.', Icons.speed_rounded, '6 min'),
    const SizedBox(height: 12), const GlassCard(child: Text('Learning note\nThis app is a conceptual model. Actual transaction ordering, fee units, and mempool policies vary across networks.', style: TextStyle(color: AppColors.muted, height: 1.5))),
  ]);
  Widget _lesson(String n, String title, String body, IconData icon, String time) => Padding(padding: const EdgeInsets.only(bottom: 12), child: GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(icon, color: AppColors.blue), const SizedBox(width: 10), Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold))), Text(time, style: const TextStyle(color: AppColors.muted, fontSize: 11))]), const SizedBox(height: 12), Text(body, style: const TextStyle(color: AppColors.muted, height: 1.5)), const SizedBox(height: 10), Text('LESSON $n', style: const TextStyle(color: AppColors.violet, fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.bold))])));
}
