import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_card.dart';
import '../../../core/widgets/section_title.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.onOpenSimulation, required this.onOpenModules});
  final VoidCallback onOpenSimulation;
  final VoidCallback onOpenModules;

  @override
  Widget build(BuildContext context) => ListView(
        padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
        children: [
          Row(children: [
            const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('CHAINLEARN  /  FIELD GUIDE', style: TextStyle(color: AppColors.blue, letterSpacing: 1.5, fontSize: 10, fontWeight: FontWeight.w800)),
              SizedBox(height: 7),
              Text('Understand the\nchain, visually.', style: TextStyle(fontSize: 27, height: 1.08, fontWeight: FontWeight.w800, letterSpacing: -.5)),
            ])),
            Container(width: 48, height: 48, decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.violet.withValues(alpha: .13),
              border: Border.all(color: AppColors.violet.withValues(alpha: .3)),
            ), child: const Icon(Icons.school_outlined, color: AppColors.blue)),
          ]),
          const SizedBox(height: 20),
          GlassCard(glow: true, onTap: onOpenSimulation, padding: const EdgeInsets.all(19), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 38, height: 38, decoration: BoxDecoration(
                color: AppColors.blue.withValues(alpha: .12), borderRadius: BorderRadius.circular(13)),
                child: const Icon(Icons.hub_outlined, color: AppColors.blue, size: 21)),
              const SizedBox(width: 11),
              const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('INTERACTIVE LAB', style: TextStyle(color: AppColors.blue, fontSize: 9, letterSpacing: 1.3, fontWeight: FontWeight.w800)),
                SizedBox(height: 3), Text('Your first block', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ])),
              _pill('3 MIN'),
            ]),
            const SizedBox(height: 17),
            const Text('See pending transactions compete for limited block space. Change fee priority and watch the queue respond.', style: TextStyle(color: AppColors.muted, height: 1.45, fontSize: 13)),
            const SizedBox(height: 17),
            Row(children: [
              const Text('Open simulation', style: TextStyle(color: AppColors.blue, fontWeight: FontWeight.w700)),
              const SizedBox(width: 7), const Icon(Icons.arrow_forward_rounded, size: 17, color: AppColors.blue),
              const Spacer(), _pulseDots(),
            ]),
          ])),
          const SizedBox(height: 23),
          Row(children: [
            const Expanded(child: SectionTitle('Learning path', trailing: '3 modules')),
            TextButton(onPressed: onOpenModules, child: const Text('View all')),
          ]),
          const SizedBox(height: 7),
          _module('01', 'Network state', 'Blocks, height and shared state', Icons.account_tree_outlined, AppColors.blue, onOpenModules),
          const SizedBox(height: 9),
          _module('02', 'Mempool', 'Where pending transactions wait', Icons.hourglass_top_rounded, AppColors.violet, onOpenModules),
          const SizedBox(height: 9),
          _module('03', 'Fee priority', 'Compare low and high fee scores', Icons.speed_rounded, AppColors.amber, onOpenModules),
          const SizedBox(height: 22),
          const SectionTitle('KEY IDEA'),
          const SizedBox(height: 10),
          const GlassCard(padding: EdgeInsets.all(15), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.lightbulb_outline_rounded, color: AppColors.amber, size: 20),
            SizedBox(width: 11),
            Expanded(child: Text('Pending means waiting for inclusion. In this learning model, higher fee scores get considered first, while limited block capacity can leave some transactions queued.', style: TextStyle(color: AppColors.muted, height: 1.5, fontSize: 12))),
          ])),
          const SizedBox(height: 14),
          const Center(child: Text('OFFLINE LEARNING SIMULATION  •  NO REAL TRANSACTIONS', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 8, letterSpacing: .8))),
        ],
      );

  Widget _pill(String label) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(color: AppColors.blue.withValues(alpha: .1), borderRadius: BorderRadius.circular(30), border: Border.all(color: AppColors.blue.withValues(alpha: .2))),
        child: Text(label, style: const TextStyle(color: AppColors.blue, fontSize: 9, fontWeight: FontWeight.w800, letterSpacing: .7)),
      );

  Widget _module(String number, String title, String subtitle, IconData icon, Color color, VoidCallback tap) => GlassCard(
        onTap: tap,
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
        child: Row(children: [
          Container(width: 39, height: 39, decoration: BoxDecoration(color: color.withValues(alpha: .1), borderRadius: BorderRadius.circular(13), border: Border.all(color: color.withValues(alpha: .15))), child: Icon(icon, color: color, size: 19)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
            const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 10.5)),
          ])),
          Text(number, style: TextStyle(color: color.withValues(alpha: .8), fontSize: 11, fontWeight: FontWeight.w800)),
          const SizedBox(width: 4), const Icon(Icons.chevron_right_rounded, size: 17, color: AppColors.muted),
        ]),
      );

  Widget _pulseDots() => Row(children: List.generate(3, (index) => Container(
        margin: const EdgeInsets.only(left: 4), width: 5, height: 5,
        decoration: BoxDecoration(shape: BoxShape.circle, color: index == 0 ? AppColors.blue : AppColors.violet.withValues(alpha: .6)),
      )));
}
