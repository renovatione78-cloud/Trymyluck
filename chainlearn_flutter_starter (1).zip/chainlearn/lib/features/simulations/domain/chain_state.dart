import 'transaction.dart';

class BlockRecord {
  const BlockRecord({required this.height, required this.hash, required this.transactions, required this.gasUsed});
  final int height;
  final String hash;
  final List<SimTransaction> transactions;
  final int gasUsed;
}

class ChainState {
  const ChainState({required this.height, required this.blocks, required this.pending,
    required this.totalGasCapacity, required this.lastEvent});
  final int height;
  final List<BlockRecord> blocks;
  final List<SimTransaction> pending;
  final int totalGasCapacity;
  final String lastEvent;

  factory ChainState.initial() => const ChainState(
    height: 12840, blocks: [], pending: [], totalGasCapacity: 12000,
    lastEvent: 'Network ready — add transactions to explore the mempool.');

  ChainState copyWith({int? height, List<BlockRecord>? blocks, List<SimTransaction>? pending,
    String? lastEvent}) => ChainState(height: height ?? this.height,
    blocks: blocks ?? this.blocks, pending: pending ?? this.pending,
    totalGasCapacity: totalGasCapacity, lastEvent: lastEvent ?? this.lastEvent);
}
