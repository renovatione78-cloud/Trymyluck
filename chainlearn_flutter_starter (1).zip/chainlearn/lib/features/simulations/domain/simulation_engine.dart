import 'chain_state.dart';
import 'transaction.dart';

class SimulationEngine {
  static ChainState add(ChainState state, SimTransaction tx) => state.copyWith(
    pending: [...state.pending, tx], lastEvent: 'Transaction ${tx.id} entered the pending pool.');

  static ChainState mineNextBlock(ChainState state) {
    if (state.pending.isEmpty) return state.copyWith(lastEvent: 'The pool is empty. Add a transaction first.');
    final sorted = [...state.pending]..sort((a, b) => b.feeRate.compareTo(a.feeRate));
    var remaining = state.totalGasCapacity;
    final included = <SimTransaction>[];
    final stillPending = <SimTransaction>[];
    for (final tx in sorted) {
      if (tx.gasLimit <= remaining) {
        remaining -= tx.gasLimit;
        included.add(tx.withStatus(TxStatus.included));
      } else {
        stillPending.add(tx);
      }
    }
    final nextHeight = state.height + 1;
    final block = BlockRecord(height: nextHeight, hash: '0x${(nextHeight * 7919).toRadixString(16)}',
      transactions: included, gasUsed: state.totalGasCapacity - remaining);
    return state.copyWith(height: nextHeight, blocks: [block, ...state.blocks].take(6).toList(),
      pending: stillPending,
      lastEvent: 'Block $nextHeight included ${included.length} transaction(s); ${stillPending.length} remain pending.');
  }

  static ChainState reset() => ChainState.initial();
}
