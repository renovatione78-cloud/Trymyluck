enum TxStatus { pending, included }

class SimTransaction {
  const SimTransaction({required this.id, required this.from, required this.to,
    required this.amount, required this.gasLimit, required this.feeRate,
    this.status = TxStatus.pending});
  final String id;
  final String from;
  final String to;
  final double amount;
  final int gasLimit;
  /// Fictional priority score in learning units, not a real gas price.
  final int feeRate;
  final TxStatus status;

  SimTransaction withStatus(TxStatus value) => SimTransaction(
    id: id, from: from, to: to, amount: amount, gasLimit: gasLimit,
    feeRate: feeRate, status: value);
}
