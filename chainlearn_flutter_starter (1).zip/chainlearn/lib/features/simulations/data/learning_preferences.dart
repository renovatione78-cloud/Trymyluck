import 'package:shared_preferences/shared_preferences.dart';

class LearningPreferences {
  static const _nameKey = 'learner_name';
  static const _lessonKey = 'last_lesson';
  Future<String> readName() async => (await SharedPreferences.getInstance()).getString(_nameKey) ?? 'Learner';
  Future<void> saveName(String name) async => (await SharedPreferences.getInstance()).setString(_nameKey, name);
  Future<void> saveLastLesson(String id) async => (await SharedPreferences.getInstance()).setString(_lessonKey, id);
  Future<String?> readLastLesson() async => (await SharedPreferences.getInstance()).getString(_lessonKey);
}
