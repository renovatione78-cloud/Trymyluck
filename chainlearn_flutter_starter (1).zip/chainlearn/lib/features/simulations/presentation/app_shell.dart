import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../home/presentation/home_screen.dart';
import '../../modules/presentation/modules_screen.dart';
import 'profile_screen.dart';
import 'simulation_screen.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}
class _AppShellState extends State<AppShell> {
  int _index = 0;
  void _go(int i) => setState(() => _index = i);
  @override
  Widget build(BuildContext context) {
    final pages = [HomeScreen(onOpenSimulation: () => _go(2), onOpenModules: () => _go(1)), const ModulesScreen(), const SimulationScreen(), const ProfileScreen()];
    return Scaffold(body: SafeArea(child: AnimatedSwitcher(duration: const Duration(milliseconds: 240), child: KeyedSubtree(key: ValueKey(_index), child: pages[_index]))),
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: _go, destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: AppColors.blue), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book, color: AppColors.blue), label: 'Modules'),
        NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle, color: AppColors.blue), label: 'Simulations'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: AppColors.blue), label: 'Profile'),
      ]));
  }
}
