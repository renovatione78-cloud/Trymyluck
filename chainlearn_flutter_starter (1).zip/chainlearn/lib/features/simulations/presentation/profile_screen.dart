import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_card.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [Text('Profile', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)), const SizedBox(height: 18), const GlassCard(glow: true, child: Row(children: [CircleAvatar(radius: 25, backgroundColor: Color(0x224FACFE), child: Icon(Icons.school, color: AppColors.blue)), SizedBox(width: 14), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Curious learner', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), SizedBox(height: 4), Text('Blockchain basics • Beginner', style: TextStyle(color: AppColors.muted, fontSize: 12))])])), const SizedBox(height: 18), const GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Learning progress', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height: 12), LinearProgressIndicator(value: .33, minHeight: 7, backgroundColor: Color(0x223FFFFFF), valueColor: AlwaysStoppedAnimation(AppColors.blue)), SizedBox(height: 9), Text('1 of 3 modules explored', style: TextStyle(color: AppColors.muted, fontSize: 12))])), const SizedBox(height: 18), const GlassCard(child: Row(children: [Icon(Icons.shield_outlined, color: AppColors.green), SizedBox(width: 10), Expanded(child: Text('Private by design\nYour experiments stay on this device and are not broadcast to a blockchain.', style: TextStyle(color: AppColors.muted, height: 1.5, fontSize: 12)))]))]);
}
