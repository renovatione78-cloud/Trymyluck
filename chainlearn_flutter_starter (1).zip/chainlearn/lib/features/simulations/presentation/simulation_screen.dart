import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/glass_card.dart';
import '../../../core/widgets/section_title.dart';
import '../domain/transaction.dart';
import 'simulation_controller.dart';

class SimulationScreen extends ConsumerWidget {
  const SimulationScreen({super.key});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(simulationProvider); final controller = ref.read(simulationProvider.notifier);
    final gasUsed = state.blocks.isEmpty ? 0 : state.blocks.first.gasUsed;
    return ListView(padding: const EdgeInsets.fromLTRB(20, 16, 20, 26), children: [
      Text('Simulation lab', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
      const SizedBox(height: 5), const Text('Experiment with pending transactions and block space.', style: TextStyle(color: AppColors.muted)),
      const SizedBox(height: 18),
      GlassCard(glow: true, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.link, color: AppColors.blue), const SizedBox(width: 9), const Expanded(child: Text('LOCAL CHAIN MODEL', style: TextStyle(fontSize: 11, letterSpacing: 1.2, fontWeight: FontWeight.bold))), Text('HEIGHT ${state.height}', style: const TextStyle(color: AppColors.blue, fontSize: 10, fontWeight: FontWeight.bold))]),
        const SizedBox(height: 17), Row(children: [Expanded(child: _metric('Pending', '${state.pending.length}', Icons.hourglass_empty)), Expanded(child: _metric('Block capacity', '${state.totalGasCapacity}', Icons.data_usage))]),
        const SizedBox(height: 14), ClipRRect(borderRadius: BorderRadius.circular(99), child: LinearProgressIndicator(value: gasUsed / state.totalGasCapacity, minHeight: 8, backgroundColor: Colors.white.withValues(alpha: .08), valueColor: const AlwaysStoppedAnimation(AppColors.blue))),
        const SizedBox(height: 7), Text('Last block capacity used: $gasUsed / ${state.totalGasCapacity} learning units', style: const TextStyle(color: AppColors.muted, fontSize: 11)),
      ])),
      const SizedBox(height: 18), const SectionTitle('Add a transaction'), const SizedBox(height: 10),
      Row(children: [Expanded(child: _action('Low fee', 'score 1', AppColors.amber, controller.addLowFee)), const SizedBox(width: 8), Expanded(child: _action('Standard', 'score 4', AppColors.violet, controller.addStandardFee)), const SizedBox(width: 8), Expanded(child: _action('High fee', 'score 9', AppColors.blue, controller.addHighFee))]),
      const SizedBox(height: 10), Row(children: [Expanded(child: FilledButton.icon(onPressed: controller.mineBlock, icon: const Icon(Icons.view_in_ar_outlined), label: const Text('Build next block'), style: FilledButton.styleFrom(backgroundColor: AppColors.blue.withValues(alpha: .18), foregroundColor: AppColors.blue, padding: const EdgeInsets.symmetric(vertical: 14)))), const SizedBox(width: 9), IconButton(onPressed: controller.reset, tooltip: 'Reset simulation', icon: const Icon(Icons.refresh, color: AppColors.muted))]),
      const SizedBox(height: 8), AnimatedSwitcher(duration: const Duration(milliseconds: 300), child: GlassCard(key: ValueKey(state.lastEvent), padding: const EdgeInsets.all(13), child: Row(children: [const Icon(Icons.bolt, color: AppColors.blue, size: 18), const SizedBox(width: 8), Expanded(child: Text(state.lastEvent, style: const TextStyle(color: AppColors.muted, fontSize: 12)))]))),
      const SizedBox(height: 20), SectionTitle('Pending pool', trailing: '${state.pending.length} waiting'), const SizedBox(height: 10),
      if (state.pending.isEmpty) const GlassCard(child: Center(child: Text('Pool is empty. Add a sample transaction above.', style: TextStyle(color: AppColors.muted)))) else ...state.pending.map((tx) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _txCard(tx))),
      const SizedBox(height: 12), const SectionTitle('Recent block'), const SizedBox(height: 10),
      if (state.blocks.isEmpty) const GlassCard(child: Text('Build a block to see which transactions fit.', style: TextStyle(color: AppColors.muted))) else _block(state.blocks.first),
      const SizedBox(height: 14), const Text('Simulation only • no wallet • no network requests', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 10)),
    ]);
  }
  Widget _metric(String label, String value, IconData icon) => Row(children: [Icon(icon, color: AppColors.violet, size: 17), const SizedBox(width: 8), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)), Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 10))])]);
  Widget _action(String title, String sub, Color color, VoidCallback tap) => GlassCard(onTap: tap, glow: color == AppColors.blue, padding: const EdgeInsets.symmetric(vertical: 13, horizontal: 8), child: Column(children: [Icon(Icons.add_circle_outline, color: color, size: 20), const SizedBox(height: 5), Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)), Text(sub, style: const TextStyle(color: AppColors.muted, fontSize: 10))]));
  Widget _txCard(SimTransaction tx) => GlassCard(padding: const EdgeInsets.all(13), child: Row(children: [Container(width: 34, height: 34, decoration: BoxDecoration(color: AppColors.amber.withValues(alpha: .12), borderRadius: BorderRadius.circular(11)), child: const Icon(Icons.swap_horiz, color: AppColors.amber, size: 19)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(tx.id, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)), Text('${tx.from} → ${tx.to}  •  ${tx.amount.toStringAsFixed(2)} EDU', style: const TextStyle(color: AppColors.muted, fontSize: 10))])), Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('score ${tx.feeRate}', style: const TextStyle(color: AppColors.blue, fontWeight: FontWeight.bold, fontSize: 11)), Text('${tx.gasLimit} gas', style: const TextStyle(color: AppColors.muted, fontSize: 10))])]));
  Widget _block(dynamic b) => GlassCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [const Icon(Icons.verified_outlined, color: AppColors.green, size: 18), const SizedBox(width: 8), Text('Block ${b.height}', style: const TextStyle(fontWeight: FontWeight.bold)), const Spacer(), Text('${b.gasUsed} gas used', style: const TextStyle(color: AppColors.muted, fontSize: 10))]), const SizedBox(height: 8), Text('${b.transactions.length} transaction(s) included • ${b.hash}', style: const TextStyle(color: AppColors.muted, fontSize: 11))]));
}
