import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../domain/chain_state.dart';
import '../domain/simulation_engine.dart';
import '../domain/transaction.dart';

final simulationProvider = StateNotifierProvider<SimulationController, ChainState>(
  (ref) => SimulationController());

class SimulationController extends StateNotifier<ChainState> {
  SimulationController() : super(ChainState.initial());
  int _nextId = 1;

  void addSample({required int feeRate}) {
    final id = _nextId++;
    state = SimulationEngine.add(state, SimTransaction(id: 'TX-${id.toString().padLeft(3, '0')}',
      from: '0xA${id}…91', to: '0xB${id}…4F', amount: (id % 7 + 1) * .25,
      gasLimit: 2100 + (id % 3) * 700, feeRate: feeRate));
  }
  void addLowFee() => addSample(feeRate: 1);
  void addStandardFee() => addSample(feeRate: 4);
  void addHighFee() => addSample(feeRate: 9);
  void mineBlock() => state = SimulationEngine.mineNextBlock(state);
  void reset() { _nextId = 1; state = SimulationEngine.reset(); }
}
