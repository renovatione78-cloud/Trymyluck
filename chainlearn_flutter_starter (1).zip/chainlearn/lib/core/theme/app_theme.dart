import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

abstract final class AppColors {
  static const background = Color(0xFF0F172A);
  static const surface = Color(0xFF121923);
  static const blue = Color(0xFF00F2FE);
  static const violet = Color(0xFF4FACFE);
  static const text = Color(0xFFF4F7FB);
  static const muted = Color(0xFF9AA9BD);
  static const border = Color(0x33FFFFFF);
  static const green = Color(0xFF51E3A4);
  static const amber = Color(0xFFFFC857);
}

abstract final class AppTheme {
  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: const ColorScheme.dark(
          primary: AppColors.blue,
          secondary: AppColors.violet,
          surface: AppColors.surface,
        ),
        textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).apply(
          bodyColor: AppColors.text, displayColor: AppColors.text,
        ),
        useMaterial3: true,
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: const Color(0xF20B1220),
          indicatorColor: AppColors.blue.withValues(alpha: .13),
          labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
        ),
      );
}
