import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.glow = false, this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final bool glow;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(22),
    child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
      child: Material(color: Colors.white.withValues(alpha: .045), child: InkWell(onTap: onTap,
        borderRadius: BorderRadius.circular(22), child: Container(padding: padding,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(22),
            border: Border.all(color: glow ? AppColors.blue.withValues(alpha: .45) : AppColors.border),
            boxShadow: glow ? [BoxShadow(color: AppColors.blue.withValues(alpha: .08), blurRadius: 24)] : null),
          child: child)))));
}
