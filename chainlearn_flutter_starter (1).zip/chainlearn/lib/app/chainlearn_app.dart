import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../features/simulations/presentation/app_shell.dart';

class ChainLearnApp extends StatelessWidget {
  const ChainLearnApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ChainLearn',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        home: const AppShell(),
      );
}
