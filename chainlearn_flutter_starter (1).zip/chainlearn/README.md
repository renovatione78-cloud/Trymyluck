# ChainLearn — Android learning app

A mobile-first, local-only learning app that demonstrates blockchain network state, a mempool-style pending queue, block capacity, and simplified low-fee priority. It uses fictional learning units. It does not connect to a wallet or a real blockchain and never submits transactions.

## Build an APK with GitHub from your phone

You do not need Flutter or a computer on your phone. GitHub Actions builds the APK in the cloud.

1. Download and extract this ZIP on your phone. Open the **`chainlearn`** folder; upload the files and folders inside it to the root of your GitHub repository. Keep hidden items such as `.github` included. The easiest reliable method on Android is GitHub in Chrome with **Desktop site** enabled, then **Add file → Upload files**. If the browser cannot upload folders, use a Git client app that can push a local project folder.
2. Create a new GitHub repository. For a personal project, a private repository is fine. Do not add a separate README or license during repository creation, because this folder already contains the project files.
3. Commit the project to the `main` branch. The workflow at `.github/workflows/build-android.yml` starts automatically after the commit. You can also start it from **Actions → Build Android APK → Run workflow**.
4. In GitHub, open **Actions**, select the latest successful **Build Android APK** run, then download the **`chainlearn-android-apk`** artifact. GitHub downloads it as a ZIP; extract that ZIP to get `app-release.apk` and install it on your Android phone.

If GitHub shows a workflow approval prompt for a first-time run, approve that run in the GitHub Actions page. The workflow only checks out this repository, generates the standard Android wrapper, downloads Flutter packages, builds the app, and stores the APK as a temporary workflow artifact for 14 days.

## Build locally

With Flutter stable installed, run these commands from this folder:

```bash
flutter create --platforms=android --org com.example .
flutter pub get
flutter run
# or
flutter build apk --release
```

The Android host is generated during the workflow so the repository stays focused on the app source. The package ID is `com.example.chainlearn`; change `--org` and the Android package settings together before publishing under your own brand.

## What is included

- Home, Modules, Simulations, and Profile tabs.
- Dark charcoal interface with neon blue and electric violet accents, translucent glass cards, responsive spacing, and animated tab transitions.
- Lessons on network state, pending transactions, fee priority, and block capacity.
- Deterministic, offline simulation managed with Riverpod.
- A GitHub Actions workflow that builds and uploads a release APK on each push to `main` or `master`.

## Project structure

```text
.github/workflows/build-android.yml   GitHub cloud APK build
lib/
  main.dart                           App entry and ProviderScope
  app/chainlearn_app.dart             Material app setup
  core/theme/app_theme.dart           Colors and typography
  core/widgets/                       Reusable glass cards and headings
  features/home/presentation/         Learning dashboard
  features/modules/presentation/      Lesson catalog
  features/simulations/
    data/                             Local learning preferences
    domain/                           Chain state, transactions, engine
    presentation/                     Controller, simulator, profile, tabs
android/                              Flutter-generated Android host at build time
```

See [ARCHITECTURE.md](ARCHITECTURE.md) for the state flow and learning model.
